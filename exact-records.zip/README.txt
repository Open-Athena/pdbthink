Exact UTF-8 system/user prompts and stored assistant output for the 25 Snowball questions,
plus every available Astra failure in the 88-question original and no-tools runs.
Empty output files are genuinely empty assistant content. Separate provider reasoning fields
are not part of the scored raw_response. The Astra audit separately includes available
provider reasoning and the raw provider response; it does not claim to expose hidden tokens.
Original score JSON records and all model output files are unmodified.
snowball-fixed is a post-hoc reanalysis of the same Snowball output, not new inference.
Its separate scoring-input and normalisation files show the complete transformation.
