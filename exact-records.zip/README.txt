Exact UTF-8 system/user prompts for all 88 coordinate questions, with all available
original and explicit-no-tools assistant outputs, plus the separate Astra failure audit.
Qwen's complete coordinate panel is included independently of its prediction cohorts.
Missing, pending and unattempted slots have status JSON, not fabricated output files.
Empty output files are genuinely empty assistant content. Separate provider reasoning fields
are not part of the scored raw_response. Every returned answer has a thinking-status JSON;
readable provider thinking and summaries are preserved verbatim in thinking/*.json and
thinking/*.html, referenced by that metadata. Encrypted blocks are labelled as unreadable;
no hidden reasoning is reconstructed. Thinking files can be opened independently offline.
All prompts, model output files and scoring values are unmodified.
Private deployment identifiers in GLM manifest metadata, score run IDs and source paths
are replaced with public aliases. Archive hashes describe these published copies;
source hashes refer to the original frozen records retained privately.
snowball-fixed is a post-hoc reanalysis of the same Snowball output, not new inference.
Its separate scoring-input and normalisation files show the complete transformation.
