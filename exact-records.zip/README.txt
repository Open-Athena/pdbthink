Exact UTF-8 system/user prompts and stored assistant output for the 25 Snowball questions.
Empty output files are genuinely empty assistant content. Separate provider reasoning fields
are not part of the scored raw_response and are not represented as assistant content here.
Score JSON records are unmodified. Source text is not shortened, repaired or normalised.
