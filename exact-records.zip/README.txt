Exact UTF-8 system/user prompts for all 88 coordinate questions, with all available
original and explicit-no-tools assistant outputs, plus the separate Astra failure audit.
Qwen's complete coordinate panel is included independently of its prediction cohorts.
Missing, pending and unattempted slots have status JSON, not fabricated output files.
Empty output files are genuinely empty assistant content. Separate provider reasoning fields
are not part of the scored raw_response. The Astra audit separately includes available
provider reasoning and the raw provider response; it does not claim to expose hidden tokens.
Original score JSON records and all model output files are unmodified.
snowball-fixed is a post-hoc reanalysis of the same Snowball output, not new inference.
Its separate scoring-input and normalisation files show the complete transformation.
