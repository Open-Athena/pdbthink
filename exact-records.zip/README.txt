Exact UTF-8 system/user prompts and stored assistant output for the 25 Snowball questions.
Empty output files are genuinely empty assistant content. Separate provider reasoning fields
are not part of the scored raw_response and are not represented as assistant content here.
Original score JSON records and all model output files are unmodified.
snowball-fixed is a post-hoc reanalysis of the same Snowball output, not new inference.
Its separate scoring-input and normalisation files show the complete transformation.
