"""Score saved Snowball responses under a separate, versioned box policy."""

from __future__ import annotations

from collections import Counter
from pathlib import Path

from pdbthink.dataset import load_dataset
from pdbthink.evaluation.runner import dataset_fingerprint
from pdbthink.evaluation.score import _scoring_parameters, summarise
from pdbthink.scoring import score_response
from pdbthink.scoring.boxed import BOXED_POLICY, BOXED_POLICY_VERSION, normalise_terminal_box
from pdbthink.util import REPO_ROOT, read_json, read_jsonl, sha256_bytes, write_json, write_jsonl
from scripts.run_snowball import TRACKS


SOURCE = REPO_ROOT / "runs/snowball_step38_v1"
OUTPUT = REPO_ROOT / "runs/snowball_fixed_v1"


def rescore(track: str, dataset_name: str) -> dict:
    source = SOURCE / track
    target = OUTPUT / track
    instances, renders = load_dataset(REPO_ROOT / "data/datasets" / dataset_name)
    by_render = {r.render_id: r for r in renders}
    by_instance = {i.semantic_instance_id: i for i in instances}
    original_summary = read_json(source / "scores/summary.json")
    assert original_summary["scored_dataset_fingerprint"] == dataset_fingerprint(renders)
    original = list(read_jsonl(source / "scores/scores.jsonl"))
    latest = {
        (r["run_id"], r["render_id"], r["completion_index"]): r
        for r in read_jsonl(source / "responses/results.jsonl")
    }
    scored, transformations = [], []
    for row in original:
        response = latest[(row["run_id"], row["render_id"], row["completion_index"])]
        assert not response.get("error") and not row["api_error"]
        render = by_render[row["render_id"]]
        kwargs = dict(
            parameters=_scoring_parameters(by_instance[render.semantic_instance_id]),
            truncated=response["truncated"], provider_refusal=response["refusal"],
        )
        original_check = score_response(response["raw_response"], render.answer_schema, render.gold_answer, **kwargs)
        assert original_check["score"] == row["detail"], row["render_id"]
        for name in ("format_error", "refusal", "truncated"):
            assert original_check[name] == row[name]
        fix = normalise_terminal_box(response["raw_response"])
        outcome = score_response(fix["scoring_text"], render.answer_schema, render.gold_answer, **kwargs)
        fixed = {
            **row,
            "analysis_label": "snowball-fixed",
            "analysis_version": BOXED_POLICY_VERSION,
            "score": outcome["score"]["score"],
            "correct": bool(outcome["score"].get("correct")),
            "detail": outcome["score"],
            "parsed_answer": outcome["parsed"],
            **{k: outcome[k] for k in ("format_error", "refusal", "truncated")},
        }
        scored.append(fixed)
        transformations.append({
            "run_id": row["run_id"], "render_id": row["render_id"],
            "completion_index": row["completion_index"], "question_family": row["question_family"],
            **fix,
            "original_response_sha256": sha256_bytes(response["raw_response"].encode()),
            "scoring_text_sha256": sha256_bytes(fix["scoring_text"].encode()),
            "original_correct": row["correct"], "fixed_correct": fixed["correct"],
            "original_format_error": row["format_error"], "fixed_format_error": fixed["format_error"],
        })
    summary = summarise(scored)
    summary.update(
        analysis_label="snowball-fixed", analysis_version=BOXED_POLICY_VERSION,
        scored_dataset_fingerprint=original_summary["scored_dataset_fingerprint"],
        run_config=original_summary["run_config"],
    )
    write_jsonl(target / "scores/scores.jsonl", scored)
    write_json(target / "scores/summary.json", summary)
    write_jsonl(target / "transformations.jsonl", transformations)
    family_counts = Counter(r["question_family"] for r in scored)
    def exact_macro(rows):
        return sum(sum(bool(r["correct"]) for r in rows if r["question_family"] == f) / n
                   for f, n in family_counts.items()) / len(family_counts)
    return {
        "responses": len(scored), "responses_normalised": sum(t["changed"] for t in transformations),
        "original_correct": sum(r["correct"] for r in original),
        "fixed_correct": sum(r["correct"] for r in scored),
        "original_exact_macro": exact_macro(original) if track == "coordinate" else None,
        "fixed_exact_macro": exact_macro(scored) if track == "coordinate" else None,
        "original_format_errors": original_summary["format_errors"],
        "fixed_format_errors": summary["format_errors"],
        "changed_verdicts": [{k: t[k] for k in ("render_id", "completion_index", "question_family", "original_correct", "fixed_correct", "final_answer")}
                             for t in transformations if t["original_correct"] != t["fixed_correct"]],
        **({"original_eligible": original_summary["sequence_prediction"]["n_accuracy_eligible"],
            "fixed_eligible": summary["sequence_prediction"]["n_accuracy_eligible"]} if track != "coordinate" else {}),
    }


def main():
    # Hash both raw and original scored files before work; verify no overwrite.
    inputs = [p for p in SOURCE.rglob('*') if p.is_file() and p.name in
              {"results.jsonl", "scores.jsonl", "summary.json", "run_config.json", "context-plan.json"}]
    hashes = {str(p.relative_to(REPO_ROOT)): sha256_bytes(p.read_bytes()) for p in inputs}
    tracks = {track: rescore(track, dataset) for track, (dataset, _) in TRACKS.items()}
    assert all(sha256_bytes((REPO_ROOT / p).read_bytes()) == digest for p, digest in hashes.items())
    code = [Path(__file__), REPO_ROOT / "src/pdbthink/scoring/boxed.py",
            REPO_ROOT / "src/pdbthink/scoring/parse.py", REPO_ROOT / "src/pdbthink/scoring/scorers.py",
            REPO_ROOT / "src/pdbthink/scoring/__init__.py"]
    evidence = {"analysis_label": "snowball-fixed", "analysis_version": BOXED_POLICY_VERSION,
                "policy": BOXED_POLICY, "post_hoc": True, "new_inference": False,
                "original_files_unchanged": True, "source_hashes": hashes,
                "code_hashes": {str(p.resolve().relative_to(REPO_ROOT)): sha256_bytes(p.read_bytes()) for p in code},
                "tracks": tracks}
    write_json(OUTPUT / "analysis.json", evidence)
    import json
    print(json.dumps(tracks, indent=2))


if __name__ == "__main__":
    main()
