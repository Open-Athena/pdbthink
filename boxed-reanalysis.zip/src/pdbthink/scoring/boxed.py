"""Versioned, opt-in formatting sensitivity analysis; never a default parser."""

from __future__ import annotations

import re
from typing import Any


BOXED_POLICY_VERSION = "snowball-boxed-v1"
BOXED_POLICY = (
    "Use the last balanced \\boxed{...} expression only when it ends the response "
    "apart from whitespace, Markdown/math delimiters or punctuation. Preserve its "
    "contents, replace LaTeX escaped spaces with ordinary spaces, and add FINAL: "
    "if absent. Preserve preceding reasoning. Leave all other responses unchanged. "
    "Do not translate residue names, repair numbers or structures, search for a "
    "correct answer, or relax gold labels, tolerances, refusal or truncation rules."
)
_BOX = re.compile(r"(?<!\\)\\boxed\s*\{")
_TRAILING_FORMAT = re.compile(r"(?:[\s$`*_.,;]|\\[\])])*")


def normalise_terminal_box(text: str) -> dict[str, Any]:
    """Recognise a terminal boxed answer without consulting the question or gold.

    Selecting by position, including when the box contradicts an earlier FINAL,
    prevents this sensitivity analysis from choosing the best of several guesses.
    An incomplete final box and a box followed by prose remain untouched.
    """
    result: dict[str, Any] = {
        "policy_version": BOXED_POLICY_VERSION,
        "changed": False,
        "reason": "no_terminal_balanced_box",
        "scoring_text": text,
        "boxed_text": None,
        "final_answer": None,
        "inserted_final_marker": False,
        "escaped_spaces_replaced": 0,
    }
    # Walk outermost boxes in order; nested braces must not truncate the answer.
    boxes: list[tuple[int, int, int]] = []
    cursor = 0
    while match := _BOX.search(text, cursor):
        depth, pos = 1, match.end()
        while pos < len(text) and depth:
            char = text[pos]
            if char == "\\":
                pos += 2
                continue
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
            pos += 1
        if depth:
            return result
        boxes.append((match.start(), match.end(), pos))
        cursor = pos
    if not boxes:
        return result
    start, inner_start, end = boxes[-1]
    if not _TRAILING_FORMAT.fullmatch(text[end:]):
        return result
    inner = text[inner_start : end - 1].strip()
    spaces = inner.count("\\ ")
    inner = inner.replace("\\ ", " ")
    has_marker = bool(re.match(r"(?i)^FINAL\s*:", inner))
    final_answer = inner if has_marker else "FINAL: " + inner
    result.update(
        changed=True,
        reason="terminal_box_recognised",
        scoring_text=text[:start] + "\n" + final_answer + "\n",
        boxed_text=text[start:end],
        box_start=start,
        box_end=end,
        final_answer=final_answer,
        inserted_final_marker=not has_marker,
        escaped_spaces_replaced=spaces,
    )
    return result
