"""Protect the boundary between formatting correction and answer repair."""

import pytest

from pdbthink.scoring import score_response
from pdbthink.scoring.boxed import normalise_terminal_box


@pytest.mark.parametrize("text", [
    r"\boxed{FINAL: A, B}",
    r"\boxed{A, B}",
    r"\[\boxed{A, B}\]",
    r"$\boxed{A, B}$",
])
def test_terminal_box_recovers_answer(text):
    fixed = normalise_terminal_box(text)
    assert fixed["changed"]
    outcome = score_response(fixed["scoring_text"], "string_set", {"value": ["A", "B"]})
    assert outcome["score"]["correct"]


def test_last_box_wins_even_when_it_makes_answer_wrong():
    text = "FINAL: 46\n" + r"\boxed{46}" + "\n" + r"\boxed{47}"
    fixed = normalise_terminal_box(text)
    assert fixed["final_answer"] == "FINAL: 47"
    assert not score_response(fixed["scoring_text"], "integer", {"value": 46})["score"]["correct"]


@pytest.mark.parametrize("text", [
    "FINAL: A",
    r"\boxed{A} is only an example.",
    r"\boxed{A} then \boxed{B",
    r"\boxed{A} " + "\nFINAL: B",
    r"\\boxed{A}",
])
def test_nonterminal_or_incomplete_box_is_not_used(text):
    assert normalise_terminal_box(text)["scoring_text"] == text


def test_balanced_braces_and_escaped_braces_preserve_contents():
    fixed = normalise_terminal_box(r"\boxed{\text{A}, \{B\}}")
    assert fixed["final_answer"] == r"FINAL: \text{A}, \{B\}"


def test_latex_spacing_is_only_a_formatting_change():
    fixed = normalise_terminal_box(r"\boxed{predominantly\ alpha\ helical}")
    assert fixed["final_answer"] == "FINAL: predominantly alpha helical"
    assert fixed["escaped_spaces_replaced"] == 2


def test_does_not_repair_residue_or_empty_answer():
    for text in [r"\boxed{A:GLY137:CA}", r"\boxed{FINAL:}"]:
        fixed = normalise_terminal_box(text)
        assert not score_response(fixed["scoring_text"], "atom", {"value": "A:G137:CA"})["score"]["correct"]


@pytest.mark.parametrize("flag", ["truncated", "provider_refusal"])
def test_fix_does_not_override_provider_flags(flag):
    fixed = normalise_terminal_box(r"\boxed{46}")
    result = score_response(fixed["scoring_text"], "integer", {"value": 46}, **{flag: True})
    assert result["score"]["score"] == 0
    assert not result["score"]["correct"]
